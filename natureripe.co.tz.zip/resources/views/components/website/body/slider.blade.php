<div>
    <!-- Simplicity is the ultimate sophistication. - Leonardo da Vinci -->
    <div class="relative h-4/5">
         <div class="inset-0 w-screen h-96 flex items-center justify-center pt-12 mt-5 transition-all ease-in-out duration-1000 transform translate-x-0 slide">
            <img src="{{ asset('img/slider.png') }}" alt="slider">
        </div>
    </div>
</div>