<div>
    <!-- Well begun is half done. - Aristotle -->
</div>

<div class="py-5 justify-center grid grid-cols-1 md:grid-cols-3 gap-2">

        <div class="max-w-sm rounded overflow-hidden shadow-lg">
            <img src="{{ asset('img/Stuffed-Peppers.png') }}" alt="staffedpappers">
            <div class="card pb-100 w-3/4 justify-center">
                <div class="card-body shadow-lg bg-slate-600">
                    <div>
                        <div class="font-extr abold font-baton, sans-serif text-3xl tracking-wider">RECEPIES</div>
                    </div> 
                    <P>Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
                    Pariatur optio ex voluptatum recusandae quas accusamus cumque 
                    iste illum facere, consequuntur placeat suscipit necessitatibus 
                    animi quo, eos laborum commodi nam reiciendis!
                    </P>
                </div>
            </div>
            <div class="pt-4 pb-2">
                <span class="inline-block bg-red-600 px-3 py-3 text-sm font-semibold text-white mr-2 mb-2 hover:bg-white hover:text-red-600 hover:border-2 hover:border-red-600">VIEW RECEPIES</span>
            </div>
        </div>
        <div class="max-w-sm rounded overflow-hidden shadow-lg" >
            <img src="{{ asset('img/Stuffed-Peppers.png') }}" alt="staffedpappers">
            <div>
                    <div>
                        <div class="font-extr abold font-baton, sans-serif text-3xl tracking-wider">RECEPIES</div>
                    </div> 
                    <P>Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
                    Pariatur optio ex voluptatum recusandae quas accusamus cumque 
                    iste illum facere, consequuntur placeat suscipit necessitatibus 
                    animi quo, eos laborum commodi nam reiciendis!
                    </P>
                    
            </div>
            <div class="pt-4 pb-2">
                <span class="inline-block bg-red-600 px-3 py-3 text-sm font-semibold text-white mr-2 mb-2 hover:bg-white hover:text-red-600 hover:border-2 hover:border-red-600">VIEW RECEPIES</span>
            </div>

         </div>
         <div class="max-w-sm rounded overflow-hidden shadow-lg" >
            <img src="{{ asset('img/Stuffed-Peppers.png') }}" alt="staffedpappers">
            <div>
                    <div>
                        <div class="font-extr abold font-baton, sans-serif text-3xl tracking-wider">RECEPIES</div>
                    </div> 
                    <P>Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
                    Pariatur optio ex voluptatum recusandae quas accusamus cumque 
                    iste illum facere, consequuntur placeat suscipit necessitatibus 
                    animi quo, eos laborum commodi nam reiciendis!
                    </P>
                    
            </div>
            <div class="pt-4 pb-2">
                <span class="inline-block bg-red-600 px-3 py-3 text-sm font-semibold text-white mr-2 mb-2 hover:bg-white hover:text-red-600 hover:border-2 hover:border-red-600">VIEW RECEPIES</span>
            </div>

         </div>

    
</div>