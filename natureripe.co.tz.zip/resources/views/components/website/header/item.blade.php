<div class="hover:border-b-2 hover:border-red-600 {{ $show == false ? 'hidden md:block' : '' }}">
    <!-- Simplicity is the essence of happiness. - Cedric Bledsoe -->
    <a href="{{ $href }}">{{ $title }}</a>
</div>