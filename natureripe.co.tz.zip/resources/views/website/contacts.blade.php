@extends('layouts.website')

@section('content')
    <h1>Contact Page</h1>
@endsection