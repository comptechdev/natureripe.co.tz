<div class="hover:border-b-2 hover:border-red-600 <?php echo e($show == false ? 'hidden md:block' : ''); ?>">
    <!-- Simplicity is the essence of happiness. - Cedric Bledsoe -->
    <a href="<?php echo e($href); ?>"><?php echo e($title); ?></a>
</div><?php /**PATH C:\Users\major_designs\Documents\GitHub\natureripe.co.tz\resources\views/components/website/header/item.blade.php ENDPATH**/ ?>