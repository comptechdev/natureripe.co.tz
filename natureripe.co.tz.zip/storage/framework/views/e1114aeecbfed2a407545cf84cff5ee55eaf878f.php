<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>

<?php if (isset($component)) { $__componentOriginal4da6de51cfab3f8c38a95a0555ec40ea1ded3d15 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Website\Header::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Website\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4da6de51cfab3f8c38a95a0555ec40ea1ded3d15)): ?>
<?php $component = $__componentOriginal4da6de51cfab3f8c38a95a0555ec40ea1ded3d15; ?>
<?php unset($__componentOriginal4da6de51cfab3f8c38a95a0555ec40ea1ded3d15); ?>
<?php endif; ?>
<?php echo $__env->yieldContent('content'); ?>
<?php if (isset($component)) { $__componentOriginalb40a49bbe3c371d1945b2acaf0fefd887af49f92 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Website\Footer::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Website\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb40a49bbe3c371d1945b2acaf0fefd887af49f92)): ?>
<?php $component = $__componentOriginalb40a49bbe3c371d1945b2acaf0fefd887af49f92; ?>
<?php unset($__componentOriginalb40a49bbe3c371d1945b2acaf0fefd887af49f92); ?>
<?php endif; ?>

</body>
</html><?php /**PATH C:\Users\major_designs\Documents\GitHub\natureripe.co.tz\resources\views/layouts/website.blade.php ENDPATH**/ ?>