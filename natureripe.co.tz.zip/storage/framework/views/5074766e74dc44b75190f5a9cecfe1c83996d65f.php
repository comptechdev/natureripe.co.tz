

<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginalec7b1bff16c2b0acf36e2d7758f67804b766ac0f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Website\Body\Slider::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.body.slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Website\Body\Slider::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalec7b1bff16c2b0acf36e2d7758f67804b766ac0f)): ?>
<?php $component = $__componentOriginalec7b1bff16c2b0acf36e2d7758f67804b766ac0f; ?>
<?php unset($__componentOriginalec7b1bff16c2b0acf36e2d7758f67804b766ac0f); ?>
<?php endif; ?>

<div class="relative grid grid-cols-1 md:grid-cols-3  p-3 md:p-24 justify-center gap-2">
    <?php if (isset($component)) { $__componentOriginal9cd67dd1e2c2838bf955c7c83ffce2682208587f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Website\Body\Showcase::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.body.showcase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Website\Body\Showcase::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9cd67dd1e2c2838bf955c7c83ffce2682208587f)): ?>
<?php $component = $__componentOriginal9cd67dd1e2c2838bf955c7c83ffce2682208587f; ?>
<?php unset($__componentOriginal9cd67dd1e2c2838bf955c7c83ffce2682208587f); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal9cd67dd1e2c2838bf955c7c83ffce2682208587f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Website\Body\Showcase::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.body.showcase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Website\Body\Showcase::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9cd67dd1e2c2838bf955c7c83ffce2682208587f)): ?>
<?php $component = $__componentOriginal9cd67dd1e2c2838bf955c7c83ffce2682208587f; ?>
<?php unset($__componentOriginal9cd67dd1e2c2838bf955c7c83ffce2682208587f); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal9cd67dd1e2c2838bf955c7c83ffce2682208587f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Website\Body\Showcase::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.body.showcase'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Website\Body\Showcase::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9cd67dd1e2c2838bf955c7c83ffce2682208587f)): ?>
<?php $component = $__componentOriginal9cd67dd1e2c2838bf955c7c83ffce2682208587f; ?>
<?php unset($__componentOriginal9cd67dd1e2c2838bf955c7c83ffce2682208587f); ?>
<?php endif; ?>
</div>
<?php if (isset($component)) { $__componentOriginal16246395708047981b224f341192005af3ac9570 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Website\Body\Section::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.body.section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Website\Body\Section::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16246395708047981b224f341192005af3ac9570)): ?>
<?php $component = $__componentOriginal16246395708047981b224f341192005af3ac9570; ?>
<?php unset($__componentOriginal16246395708047981b224f341192005af3ac9570); ?>
<?php endif; ?>


<?php $__env->stopSection(); ?>   
<?php echo $__env->make('layouts.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\major_designs\Documents\GitHub\natureripe.co.tz\resources\views/website/home.blade.php ENDPATH**/ ?>