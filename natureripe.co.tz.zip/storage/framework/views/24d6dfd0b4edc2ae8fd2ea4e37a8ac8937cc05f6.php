
<div class="flex justify-center py-5 space-x-5 text-md font-semibold bg-slate-200 text-red-500 shadow-lg items-center">
    <!-- Well begun is half done. - Aristotle -->
    <?php if (isset($component)) { $__componentOriginalc2b349a3468801dce4113a57607c0979b54864af = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Website\Header\Item::class, ['title' => 'HOT SOURCES'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.header.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Website\Header\Item::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2b349a3468801dce4113a57607c0979b54864af)): ?>
<?php $component = $__componentOriginalc2b349a3468801dce4113a57607c0979b54864af; ?>
<?php unset($__componentOriginalc2b349a3468801dce4113a57607c0979b54864af); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc2b349a3468801dce4113a57607c0979b54864af = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Website\Header\Item::class, ['title' => 'RECEPIES'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.header.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Website\Header\Item::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2b349a3468801dce4113a57607c0979b54864af)): ?>
<?php $component = $__componentOriginalc2b349a3468801dce4113a57607c0979b54864af; ?>
<?php unset($__componentOriginalc2b349a3468801dce4113a57607c0979b54864af); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc2b349a3468801dce4113a57607c0979b54864af = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Website\Header\Item::class, ['title' => 'ABOUT'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.header.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Website\Header\Item::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2b349a3468801dce4113a57607c0979b54864af)): ?>
<?php $component = $__componentOriginalc2b349a3468801dce4113a57607c0979b54864af; ?>
<?php unset($__componentOriginalc2b349a3468801dce4113a57607c0979b54864af); ?>
<?php endif; ?>
    <div class="item-align-start">
        <img src="<?php echo e(asset('img/FRESH.png')); ?>" alt="fresh" class="h-16">
    </div>
    <?php if (isset($component)) { $__componentOriginalc2b349a3468801dce4113a57607c0979b54864af = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Website\Header\Item::class, ['title' => 'OUR HOME'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.header.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Website\Header\Item::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2b349a3468801dce4113a57607c0979b54864af)): ?>
<?php $component = $__componentOriginalc2b349a3468801dce4113a57607c0979b54864af; ?>
<?php unset($__componentOriginalc2b349a3468801dce4113a57607c0979b54864af); ?>
<?php endif; ?>
    <div class="border-2 border-red-600 hover:bg-red-600 hover:text-white w-40 text-center">
     <a href="#" class="p-2">BUY ONLINE</a>
    </div>

    <div class="md:hidden flex items-center">
	<button class="outline-none mobile-menu-button">
		<svg
			class="w-6 h-6 text-gray-500"
			x-show="!showMenu"
			fill="none"
			stroke-linecap="round"
			stroke-linejoin="round"
			stroke-width="2"
			viewBox="0 0 24 24"
			stroke="currentColor"
		>
		<path d="M4 6h16M4 12h16M4 18h16"></path>
		</svg>
	</button>
</div>
<div class="hidden mobile-menu">
	<ul class="">
        <li><?php if (isset($component)) { $__componentOriginalc2b349a3468801dce4113a57607c0979b54864af = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Website\Header\Item::class, ['title' => 'OUR HOME','show' => true] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.header.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Website\Header\Item::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2b349a3468801dce4113a57607c0979b54864af)): ?>
<?php $component = $__componentOriginalc2b349a3468801dce4113a57607c0979b54864af; ?>
<?php unset($__componentOriginalc2b349a3468801dce4113a57607c0979b54864af); ?>
<?php endif; ?></li>
        <li><?php if (isset($component)) { $__componentOriginalc2b349a3468801dce4113a57607c0979b54864af = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Website\Header\Item::class, ['title' => 'OUR HOME'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.header.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Website\Header\Item::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2b349a3468801dce4113a57607c0979b54864af)): ?>
<?php $component = $__componentOriginalc2b349a3468801dce4113a57607c0979b54864af; ?>
<?php unset($__componentOriginalc2b349a3468801dce4113a57607c0979b54864af); ?>
<?php endif; ?></li>
        <li><?php if (isset($component)) { $__componentOriginalc2b349a3468801dce4113a57607c0979b54864af = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Website\Header\Item::class, ['title' => 'OUR HOME'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website.header.item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Website\Header\Item::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2b349a3468801dce4113a57607c0979b54864af)): ?>
<?php $component = $__componentOriginalc2b349a3468801dce4113a57607c0979b54864af; ?>
<?php unset($__componentOriginalc2b349a3468801dce4113a57607c0979b54864af); ?>
<?php endif; ?></li>
	</ul>
</div>


<script>
	// Grab HTML Elements
	const btn = document.querySelector("button.mobile-menu-button");
	const menu = document.querySelector(".mobile-menu");

	// Add Event Listeners
	btn.addEventListener("click", () => {
	menu.classList.toggle("hidden");
	});
</script>

    

</div>

</div>

<?php /**PATH C:\Users\major_designs\Documents\GitHub\natureripe.co.tz\resources\views/components/website/header.blade.php ENDPATH**/ ?>